from django.db import models
from django.core.validators import MinValueValidator
import datetime


# Create your models here.
class Order(models.Model):
    products = models.CharField(max_length=100)
    # quantity = models.IntegerField
    customerName = models.CharField(max_length=200)
    contactInfo = models.CharField(max_length=20)
    shippingLocation = models.CharField(max_length=200)
    courier = models.CharField(max_length=50)
    shippingRef = models.CharField(max_length=50)
    additionalExpenses = models.DecimalField(max_digits=100, decimal_places=2)
    notes = models.TextField


class Initial(models.Model):
    products = models.CharField(max_length=100)
    # quantity = models.IntegerField(validators=[MinValueValidator(1)])
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    customerName = models.CharField(max_length=200)
    contactInfo = models.CharField(max_length=20)
    shippingLocation = models.CharField(max_length=200)
    courier = models.CharField(max_length=50)
    shippingRef = models.CharField(max_length=50)
    additionalExpenses = models.DecimalField(max_digits=100, decimal_places=2)
    notes = models.CharField(max_length=100, blank=True)
    # user = models.CharField(max_length=100, editable=False)
    # date = models.DateTimeField(auto_now_add=True, auto_now=False)
    # date = models.DateTimeField(auto_now_add=True)


class InitialTwo(models.Model):
    products = models.CharField(max_length=100)
    # quantity = models.IntegerField(validators=[MinValueValidator(1)])
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    customerName = models.CharField(max_length=200)
    contactInfo = models.CharField(max_length=20)
    shippingLocation = models.CharField(max_length=200)
    courier = models.CharField(max_length=50)
    shippingRef = models.CharField(max_length=50)
    additionalExpenses = models.DecimalField(max_digits=100, decimal_places=2)
    notes = models.CharField(max_length=100, blank=True)
    user = models.CharField(max_length=100, editable=False)
    date = models.DateTimeField(auto_now_add=True, auto_now=False)
    # date = models.DateTimeField(auto_now_add=True)
