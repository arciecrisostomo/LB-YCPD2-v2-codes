from django.shortcuts import render, redirect
from orders.models import InitialTwo
from django.contrib import messages
from .forms import OrdersForm
from orders.models import InitialTwo
from orders.forms import OrdersForm
from .models import *
from .forms import OrdersForm

def sold_products_view(request, *args, **kwargs):
    orders = InitialTwo.objects.all()
    return render(request, "view_sold_database.html", {'orders': orders})

# Create your views here.
# def add_order(request, *args, **kwargs):
#     return render(request, "add_order.html", {})
def add_order(request):
    # if request.method == 'POST':
    #     if request.POST.get('products') and request.POST.get('quantity') and request.POST.get('customerName') and request.POST.get('contactInfo') and request.POST.get('shippingLocation') and request.POST.get('courier') and request.POST.get('shippingRef') and request.POST.get('additionalExpenses') and request.POST.get('notes'):
    #         SaveRecord = Initial()
    #         SaveRecord.products = request.POST.get('products')
    #         SaveRecord.quantity = request.POST.get('quantity')
    #         SaveRecord.customerName = request.POST.get('customerName')
    #         SaveRecord.contactInfo = request.POST.get('contactInfo')
    #         SaveRecord.shippingLocation = request.POST.get('shippingLocation')
    #         SaveRecord.courier = request.POST.get('courier')
    #         SaveRecord.shippingRef = request.POST.get('shippingRef')
    #         SaveRecord.additionalExpenses = request.POST.get('additionalExpenses')
    #         SaveRecord.notes = request.POST.get('notes')
    #         SaveRecord.Save()
    #         return redirect('home')
    #
    #     else:
    #         messages.error(request, 'Fill up errthang')
    #
    # context = {}
    #
    # return render(request, "add_order.html", context)\

    allOrders = InitialTwo.objects.all()

    form = OrdersForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        fs = form.save(commit=False)
        fs.user = request.user
        fs.save()
        return redirect('home')

    context = {'form': form, 'allOrders': allOrders}
    return render(request, "add_order.html", context)

    # form = OrdersForm()
    # if request.method == 'POST':
    #     form = OrdersForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect('home')
    #
    # context = {'form': form}
    # return render(request, "add_order.html", context)