from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.core import serializers
from dashboard.models import Order
from .forms import DashboardForm
from orders.models import Initial
# from orders.forms import OrdersForm
from .models import *
# from .forms import OrdersForm

# Create your views here.
def dashboard_with_pivot(request):
    # form = DashboardForm()
    # if request.method == 'POST':
    #     form = DashboardForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect('about_us')
    #
    # context = {'form': form}
    # # return render(request, "add_product.html", context)
    #
    # return render(request, "add_product.html", context)

    allOrders = Order.objects.all()

    form = DashboardForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        fs = form.save(commit=False)
        fs.user = request.user
        fs.save()
        return redirect('about_us')

    context = {'form': form, 'allOrders': allOrders}
    return render(request, "add_product.html", context)

def pivot_data(request):
    dataset = Order.objects.all()
    data = serializers.serialize('json', dataset)
    return JsonResponse(data, safe=False)