from django.contrib import admin
from .models import Raw, Initial

# Register your models here.
admin.site.register(Raw)
admin.site.register(Initial)