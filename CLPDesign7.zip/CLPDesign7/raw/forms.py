from django import forms
from django.forms import ModelForm
from .models import Initial

# class RawForm(forms.Form):
#     name = forms.CharField()
#     materialType = forms.CharField()
#     quantity = forms.IntegerField()
#     unitType = forms.CharField()
#     totalCost = forms.DecimalField(decimal_places=2)

class RawForm(ModelForm):
    class Meta:
        model = Initial
        fields = '__all__'