from django.db import models
from django.core.validators import MinValueValidator


# Create your models here.
class Raw(models.Model):
    name = models.CharField(max_length=200)
    materialType = models.CharField(max_length=200)
    quantity = models.DecimalField(decimal_places=0, max_digits=100)
    unitType = models.CharField(max_length=200)
    totalCost = models.DecimalField(decimal_places=2, max_digits=100)

class Initial(models.Model):
    user = models.CharField(max_length=100, editable=False)
    name = models.CharField(max_length=200)
    materialType = models.CharField(max_length=200)
    # quantity = models.DecimalField(decimal_places=0, max_digits=100)
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unitType = models.CharField(max_length=200)
    totalCost = models.DecimalField(decimal_places=2, max_digits=100)

    def __str__(self):
        return self.name