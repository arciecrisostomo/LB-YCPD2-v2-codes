from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from login import views
from products.models import Product

from orders.models import InitialTwo

# Create your views here.
def home_view(request):
    labels = []
    data = []

    queryset = InitialTwo.objects.order_by('-quantity')
    for initial in queryset:
        if initial.user == request.user.username:
            if initial.products not in labels:
                labels.append(initial.products)
                data.append(initial.quantity)
            elif initial.products in labels:
                data[labels.index(initial.products)] += initial.quantity

    return render(request, 'home.html', {
        'labels': labels,
        'data': data,
    })

def item_relation_view(request):
    obj = Product.objects.get(id=1)

    context = {
        'Number': obj.idNum,
        'Name': obj.name,
        'Type': obj.itemType
    }

    return render(request, "item_relation.html", context)


def price_adjustment_view(request, *args, **kwargs):
    # return HttpResponse("<h1>Material Price</h1>")
    return render(request, "price_adjustment.html", {})


def about_us(request, *args, **kwargs):
    return render(request, "about_us.html", {})