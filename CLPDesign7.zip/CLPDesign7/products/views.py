from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from products.models import Initial
from products.forms import ProductsForm
from .models import *
from .forms import ProductsForm

# Create your views here.
# def new_product_view(request):
#     # if request.method == 'POST':
#         # form = ProductsForm(request.POST)
#         # if form.is_valid():
#     # form = ProductsForm()
#
#         # if request.POST.get('name') and request.POST.get('itemType') and request.POST.get('sellPrice'):
#         #     saverecord = Initial()
#         #     saverecord.name = request.POST.get('name')
#         #     saverecord.itemType = request.POST.get('itemType')
#         #     saverecord.sellPrice = request.POST.get('sellPrice')
#         #     saverecord.save()
#         #
#         #     return redirect('new_raw')
#         #
#         # else:
#             messages.error(request, 'Fill up errthang')
#             # return HttpResponseRedirect('/new_raw/')
#
#     # else:
#         # form = ProductsForm()
#
#     # return render(request, 'add_product.html', {'form': form})
#     form = ProductsForm()
#
#     context = {'form':form}
#
#     return render(request, "add_product.html", context)

def existing_products_view(request):
    products = Initial.objects.all()
    return render(request, "view_products_database.html", {'products': products})

def new_product_view(request):
    allProducts = Initial.objects.all()

    form = ProductsForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        fs = form.save(commit=False)
        fs.user = request.user
        fs.save()
        return redirect('new_raw')

    context = {'form': form, 'allProducts': allProducts}
    return render(request, "add_product.html", context)

    # form = ProductsForm()
    # if request.method == 'POST':
    #     form = ProductsForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect('new_raw')
    #
    # context = {'form':form}
    # return render(request, "add_product.html", context)

    # allProducts = Initial.objects.all()
    #
    # form = ProductsForm(request.POST or None, request.FILES or None)
    # if form.is_valid():
    #     fs = form.save(commit=False)
    #     fs.user = request.user
    #     fs.save()
    #     return redirect('new_raw')
    #
    # context = {'form': form, 'allProducts': allProducts}
    # return render(request, "add_product.html", context)


# def edit_product_view(request, *args, **kwargs):
#     # return HttpResponse("<h1>Edit Product Details</h1>")
#     return render(request, "edit_product.html", {})

# def edit_product_view(request, pk):
#
#     product = Initial.objects.get(id=pk)
#
#     form = ProductsForm(instance=product)
#
#     context = {'form':form}
#     return render(request, "add_product.html", context)

def view_edit_product(request):
    products = Initial.objects.all()
    return render(request, "view_edit_product.html", {'products': products})

def edit_product_view(request, pk):
    product = Initial.objects.get(id=pk)

    form = ProductsForm(instance=product)

    if request.method == 'POST':
        form = ProductsForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('home')

    context = {'form': form}
    return render(request, "add_product.html", context)

def view_delete_product(request):
    products = Initial.objects.all()
    return render(request, "view_delete_product.html", {'products': products})

def delete_product_view(request, pk):
    product = Initial.objects.get(id=pk)
    if request.method == 'POST':
        if 'cancel' not in request.POST:
            product.delete()
        return redirect('home')

    context = {'item': product}
    return render(request, "delete_product.html", context)
